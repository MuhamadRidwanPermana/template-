# Dashboard | Money Tracker

This project is part of my youtube channel. Where i will be teaching how to create this beautiful looking dashboard with the help of Reactjs, Framer motion, tailwind css and chartjs.

<img width="1487" alt="Screenshot 2023-08-27 at 5 36 11 PM" src="https://github.com/yatharth1706/DashboardV2/assets/32243289/9141a681-b6b8-4a6c-958a-8d57e018e777">
