# sidebar_reactTailwind
sidebar using react js tailwind css

Vite + React + tailwind

1) npm i
2) npm run dev
