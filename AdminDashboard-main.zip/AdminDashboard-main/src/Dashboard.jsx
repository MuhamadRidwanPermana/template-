import React from "react";
import Sidebar from "./components/Sidebar";

const Dashboard = () => {
  return (
    <div>
      <Sidebar />
    </div>
  );
};

export default Dashboard;
