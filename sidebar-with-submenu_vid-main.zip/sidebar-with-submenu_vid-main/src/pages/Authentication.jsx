const Authentication = () => {
  return <h1>Authentication</h1>;
};

export default Authentication;
