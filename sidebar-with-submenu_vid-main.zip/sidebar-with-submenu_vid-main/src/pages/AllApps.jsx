const AllApps = () => {
  return <h1>All Apps</h1>;
};

export default AllApps;
