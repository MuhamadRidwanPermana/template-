import React from 'react'

const ChartsHeader = () => {
  return (
    <div>ChartsHeader</div>
  )
}

export default ChartsHeader