import React from 'react'

const Pyramid = () => {
  return (
    <div>Pyramid</div>
  )
}

export default Pyramid