# react-admin-dashboard
Admin Dashboard build with Vite + React and Tailwind
